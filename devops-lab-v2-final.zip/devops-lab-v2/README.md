# DevOps Training Lab v2

**Git · Ansible · Azure Pipelines**
One `git clone` + Reopen in Container = everything works. Zero manual setup.

## Quick Start (3 steps)

```bash
# 1. Clone (in WSL Ubuntu terminal)
git clone https://YOUR_ORG@dev.azure.com/YOUR_ORG/DevOps-Training/_git/devops-lab
cd devops-lab

# 2. Open in VS Code
code .
```

**3. VS Code shows:** "Reopen in Container" → Click it

⏳ First build: 5–10 min. After that: < 30 sec.

```bash
# 4. Inside container terminal — verify:
ansible all -m ping
# web01 | SUCCESS => { "ping": "pong" }
# web02 | SUCCESS => { "ping": "pong" }
# db01  | SUCCESS => { "ping": "pong" }
```

## If Docker Hub is blocked (corporate network)

Three options — try in order:

| Option | How | When |
|---|---|---|
| **1. MCR** (default) | Already configured — uses mcr.microsoft.com | Try first |
| **2. ACR** | Trainer pushes to your org ACR | If MCR blocked |
| **3. WSL2 direct** | No Docker at all | If Docker blocked |

### Option 1 — MCR (already configured)
This repo already uses `mcr.microsoft.com` (Microsoft Container Registry).
MCR is whitelisted in most corporate networks. Just open in container normally.

### Option 2 — Azure Container Registry
```bash
# Trainer runs ONCE (from any internet-connected machine):
export ACR_NAME=yourcompanyacr
bash scripts/build-and-push-to-acr.sh

# Team: login to ACR first
az login
az acr login --name yourcompanyacr

# Copy .env.example to .env and set ACR_NAME
cp .env.example .env
# edit .env: ACR_NAME=yourcompanyacr

# Open container using ACR compose file
# (update devcontainer.json to use docker-compose.acr.yml)
```

### Option 3 — WSL2 Ubuntu directly (no Docker needed)
```bash
# Run inside WSL2 Ubuntu terminal:
cd devops-lab
bash scripts/wsl2-setup.sh
```

### If proxy is the issue
```bash
export HTTP_PROXY_URL=http://proxy.company.com:8080
bash scripts/configure-docker-proxy.sh
```

## Lab Commands

```bash
# Git labs
bash git-labs/lab1-setup.sh    # Commits and selective staging
bash git-labs/lab2-setup.sh    # Branching and conflict resolution
bash git-labs/lab3-setup.sh    # Interactive rebase
bash git-labs/lab4-setup.sh    # Full GitFlow workflow

# Ansible
ansible all -m ping
ansible-inventory --graph
ansible-playbook ansible/playbooks/01-ping-test.yml
ansible-playbook ansible/playbooks/02-gather-facts.yml
ansible-playbook ansible/playbooks/03-install-nginx.yml
ansible-playbook ansible/playbooks/03-install-nginx.yml --check --diff
ansible-playbook ansible/playbooks/04-variables-loops.yml
```

## Lab Network

```
172.20.0.0/24
  devcontainer  .10  Control node (VS Code)
  web01         .21  Webservers group — port 80
  web02         .22  Webservers group — port 8080
  db01          .23  DBservers group
```

## Troubleshoot

| Problem | Fix |
|---|---|
| Docker Hub blocked | Already using MCR — should work. Try Option 2/3 if not. |
| Proxy blocking pulls | Run `bash scripts/configure-docker-proxy.sh` |
| `ansible all -m ping` fails | Run `bash scripts/post-start.sh` |
| Need to reset lab | Run `bash scripts/lab-reset.sh` |
