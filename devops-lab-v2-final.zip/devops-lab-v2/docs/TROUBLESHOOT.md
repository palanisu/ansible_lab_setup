# Troubleshooting Guide

## Docker pull blocked (most common corporate issue)

### Problem
```
Error response from daemon: pull access denied for ubuntu, repository does not exist
```
or
```
docker: Error response from daemon: Get "https://registry-1.docker.io/..."
```

### Root cause
Your corporate network blocks Docker Hub (registry-1.docker.io).

### Solutions (try in order)

---

#### ✅ Solution 1 — Already fixed! (MCR)
This repo already uses `mcr.microsoft.com` (Microsoft Container Registry), 
NOT Docker Hub. If you still get pull errors, check the exact image name in
the error — it should say `mcr.microsoft.com`, not `registry-1.docker.io`.

Test MCR access:
```bash
docker pull mcr.microsoft.com/devcontainers/base:ubuntu-22.04
```

If this works: re-run "Reopen in Container" — Docker Hub is not needed.

---

#### ✅ Solution 2 — Configure corporate proxy
If your org uses a proxy (Zscaler, Squid, etc.):
```bash
export HTTP_PROXY_URL=http://proxy.company.com:8080
bash scripts/configure-docker-proxy.sh
```
Then restart Docker and retry.

---

#### ✅ Solution 3 — Use Azure Container Registry (ACR)
Trainer builds and pushes images to your org's ACR once.
Team pulls from ACR (always allowed inside org).

```bash
# Trainer only (run from an internet-connected machine):
export ACR_NAME=yourcompanyacr
bash scripts/build-and-push-to-acr.sh

# Team members (login to ACR first):
az login
az acr login --name yourcompanyacr
cp .env.example .env
# Edit .env: ACR_NAME=yourcompanyacr
```

Then update `.devcontainer/devcontainer.json`:
```json
"dockerComposeFile": ["../docker-compose.acr.yml"],
```

---

#### ✅ Solution 4 — WSL2 direct (no Docker at all)
If Docker is completely blocked on your machine:
```bash
# Run inside WSL2 Ubuntu:
bash scripts/wsl2-setup.sh
```

---

## Docker CLI not found inside Dev Container

### Problem
```
post-create.sh: line XX: docker: command not found
```

### Root cause
Docker CLI was not installed in the Dev Container image, OR
the Docker socket was not mounted.

### Fix
The `Dockerfile` now installs `docker-ce-cli`. If you built the image before
this fix, rebuild:
```
Ctrl+Shift+P → Dev Containers: Rebuild Container
```

Verify after rebuild:
```bash
docker version      # should show Client version
docker ps           # should list running containers
```

---

## Ansible cannot reach managed nodes

### Problem
```
web01 | UNREACHABLE! => {"msg": "Failed to connect to the host via ssh"}
```

### Root cause
SSH key not yet distributed to managed nodes (usually happens on first start
or after container restart).

### Fix
```bash
# The shared volume approach (Fix B) handles this automatically.
# If still failing, run:
bash scripts/post-start.sh

# Then test:
ansible all -m ping
```

### Why it works now (Fix B explanation)
```
Old approach (broken):
  post-create.sh → docker exec lab-web01 → install key
  ❌ Fails because docker CLI not in Dev Container

New approach (Fix B — shared volume):
  post-create.sh → writes key to /ssh-keys/lab_key.pub (Docker volume)
  managed node entrypoint.sh → reads /ssh-keys/lab_key.pub → installs to authorized_keys
  ✅ No docker exec needed. Works on any Docker host.
```

---

## Permission denied on Docker socket

### Problem
```
permission denied while trying to connect to the Docker daemon socket
/var/run/docker.sock: connect: permission denied
```

### Fix
The Dockerfile adds `vscode` user to the `docker` group. If you built before
this fix, rebuild the container:
```
Ctrl+Shift+P → Dev Containers: Rebuild Container
```

Or inside the container:
```bash
sudo usermod -aG docker vscode
# Then reopen terminal
```

---

## Git identity not set

### Problem
```
Author identity unknown
*** Please tell me who you are.
```

### Fix
```bash
git config --global user.name  "Your Name"
git config --global user.email "you@company.com"
```

---

## Managed nodes lost their SSH key (after docker-compose restart)

### Why
The `lab-ssh-keys` Docker volume persists across restarts, so the key
should stay. If the volume was deleted (`docker-compose down -v`), run:
```bash
bash scripts/post-start.sh
```
This re-writes the pubkey to the shared volume. Managed nodes check
the key every 2 seconds in their entrypoint and update automatically.
