#!/bin/bash
# =================================================================
# entrypoint.sh — Managed Node startup
# Tries two methods to install the SSH public key:
#   Method 1: Read from shared volume /ssh-keys/lab_key.pub
#   Method 2: Password auth (ssh-copy-id from control node)
# Both methods work — whichever completes first wins.
# =================================================================

AUTH_KEYS="/home/ansible/.ssh/authorized_keys"
PUB_KEY_FILE="/ssh-keys/lab_key.pub"

echo "[$(hostname)] Starting sshd setup..."

# Method 1: Try shared volume (works if volume is populated)
if [ -f "$PUB_KEY_FILE" ]; then
    PUB_KEY=$(cat "$PUB_KEY_FILE")
    if ! grep -qF "$PUB_KEY" "$AUTH_KEYS" 2>/dev/null; then
        echo "$PUB_KEY" >> "$AUTH_KEYS"
        chmod 600 "$AUTH_KEYS"
        chown ansible:ansible "$AUTH_KEYS"
        echo "[$(hostname)] SSH key installed from shared volume"
    else
        echo "[$(hostname)] SSH key already in authorized_keys"
    fi
else
    echo "[$(hostname)] No shared volume key found — waiting for ssh-copy-id from control node"
fi

# Always start sshd (password + key auth both enabled)
echo "[$(hostname)] Starting sshd (password + pubkey auth enabled)..."
exec /usr/sbin/sshd -D
