#!/usr/bin/env bash
# =================================================================
# wsl2-setup.sh — OPTION 3: Pure WSL2 setup (no Docker needed)
#
# Run this INSIDE your WSL2 Ubuntu 22.04 terminal.
# This turns your WSL2 Ubuntu into the Ansible control node.
# Managed nodes = Azure VMs (provided by trainer) or local VMs.
#
# Use this if Docker Desktop is completely blocked.
#
# Usage: bash scripts/wsl2-setup.sh
# =================================================================
set -e
G="\033[0;32m"; C="\033[0;36m"; Y="\033[1;33m"; N="\033[0m"
ok()   { echo -e "${G}✓  $*${N}"; }
step() { echo -e "\n${C}▶  $*${N}"; }
warn() { echo -e "${Y}⚠  $*${N}"; }

echo -e "${C}"
echo "╔══════════════════════════════════════════════════════╗"
echo "║  DevOps Lab — WSL2 Direct Install (no Docker)       ║"
echo "╚══════════════════════════════════════════════════════╝"
echo -e "${N}"

# Check we are inside WSL2
if ! grep -qi microsoft /proc/version 2>/dev/null; then
    warn "This script should run inside WSL2 Ubuntu 22.04"
    warn "Open: Start → Ubuntu 22.04"
fi

# ── Step 1: System packages ───────────────────────────────────────────────────
step "Installing system packages..."
sudo apt-get update -qq
sudo apt-get install -y --no-install-recommends     python3 python3-pip python3-venv python3-dev     openssh-client sshpass     curl wget git vim nano tree jq unzip     iputils-ping dnsutils     build-essential libssl-dev libffi-dev
ok "System packages installed"

# ── Step 2: Ansible via pip ───────────────────────────────────────────────────
step "Installing Ansible..."
pip3 install --user --no-cache-dir     ansible==8.5.0     ansible-lint==6.22.1     paramiko netaddr jmespath requests

# Add pip user bin to PATH
if ! grep -q ".local/bin" ~/.bashrc; then
    echo "export PATH=\$PATH:~/.local/bin" >> ~/.bashrc
fi
export PATH=$PATH:~/.local/bin
ok "Ansible installed: $(ansible --version | head -1)"

# ── Step 3: Azure CLI ─────────────────────────────────────────────────────────
step "Installing Azure CLI..."
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash
az extension add --name azure-devops --yes 2>/dev/null || true
ok "Azure CLI installed: $(az --version | head -1)"

# ── Step 4: Ansible collections ──────────────────────────────────────────────
step "Installing Ansible Galaxy collections..."
ansible-galaxy collection install ansible.posix community.general --ignore-errors -q
ok "Collections installed"

# ── Step 5: Git configuration ─────────────────────────────────────────────────
step "Configuring Git..."
git config --global init.defaultBranch main
git config --global pull.rebase false
git config --global core.autocrlf input
git config --global core.editor "code --wait"
git config --global alias.lg   "log --oneline --graph --all --decorate"
git config --global alias.st   "status -sb"
git config --global alias.undo "reset --soft HEAD~1"

if [ -z "$(git config --global user.name 2>/dev/null)" ]; then
    echo ""
    warn "Set your Git identity now:"
    echo -e "  ${Y}git config --global user.name  \"Your Name\"${N}"
    echo -e "  ${Y}git config --global user.email \"you@company.com\"${N}"
fi
ok "Git configured"

# ── Step 6: SSH key ───────────────────────────────────────────────────────────
step "Generating SSH key for Ansible..."
mkdir -p ~/.ssh && chmod 700 ~/.ssh
if [ ! -f ~/.ssh/lab_key ]; then
    ssh-keygen -t ed25519 -C "devops-lab-$(date +%Y%m%d)"                -f ~/.ssh/lab_key -N "" -q
    chmod 600 ~/.ssh/lab_key
fi
ok "SSH key ready: ~/.ssh/lab_key"
echo ""
echo -e "  ${C}Your public key (send to trainer to add to lab VMs):${N}"
cat ~/.ssh/lab_key.pub
echo ""

# ── Step 7: Ansible config + inventory ───────────────────────────────────────
step "Setting up Ansible config and inventory..."
WORKSPACE="$(pwd)"
export ANSIBLE_CONFIG="$WORKSPACE/ansible/ansible.cfg"
export ANSIBLE_INVENTORY="$WORKSPACE/ansible/inventory.yml"

# Persist env vars
cat >> ~/.bashrc << ENVEOF

# DevOps Lab
export ANSIBLE_CONFIG="$WORKSPACE/ansible/ansible.cfg"
export ANSIBLE_INVENTORY="$WORKSPACE/ansible/inventory.yml"
ENVEOF
ok "Environment variables added to ~/.bashrc"

# ── Step 8: VS Code WSL extension check ──────────────────────────────────────
step "Checking VS Code..."
if command -v code &>/dev/null; then
    ok "VS Code CLI found — opening workspace..."
    code . &
else
    warn "VS Code not on PATH in WSL. Open manually: code ."
    warn "Make sure WSL extension is installed in VS Code"
fi

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
echo -e "${G}╔══════════════════════════════════════════════════╗${N}"
echo -e "${G}║  WSL2 Control Node Ready!                        ║${N}"
echo -e "${G}╚══════════════════════════════════════════════════╝${N}"
echo ""
echo -e "  ${C}Next steps:${N}"
echo -e "  1. Send your public key above to the trainer"
echo -e "  2. Trainer adds it to lab VMs"
echo -e "  3. Update ansible/inventory.yml with actual VM IPs"
echo -e "  4. Test: ${Y}ansible all -m ping${N}"
echo -e "  5. Start labs: ${Y}bash git-labs/lab1-setup.sh${N}"
echo ""
echo -e "  ${Y}Run: source ~/.bashrc${N}  to reload your shell"
echo ""
