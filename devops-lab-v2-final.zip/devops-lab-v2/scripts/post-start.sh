#!/usr/bin/env bash
# =================================================================
# post-start.sh — Runs every time the Dev Container starts
# Re-copies SSH key if managed nodes were recreated.
# =================================================================
G="\033[0;32m"; C="\033[0;36m"; Y="\033[1;33m"; N="\033[0m"

LAB_USER="ansible"
LAB_PASS="${ANSIBLE_NODE_PASSWORD:-Training@123}"

declare -A NODES=(
    ["web01"]="192.168.55.21"
    ["web02"]="192.168.55.22"
    ["db01"]="192.168.55.23"
)

echo -e "\n${C}▶  Checking managed node SSH access...${N}"

# Refresh shared volume key
[ -f /home/vscode/.ssh/lab_key.pub ] && cp /home/vscode/.ssh/lab_key.pub /ssh-keys/lab_key.pub 2>/dev/null || true

for NAME in "${!NODES[@]}"; do
    IP="${NODES[$NAME]}"
    echo -n "  $NAME ($IP) ... "

    # Test key-based auth first
    if ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 \
           -o BatchMode=yes -i /home/vscode/.ssh/lab_key \
           "${LAB_USER}@${IP}" true 2>/dev/null; then
        echo -e "${G}✓ key auth OK${N}"
    else
        # Fall back to password + re-copy key
        echo -n "${Y}key auth failed, re-running ssh-copy-id...${N} "
        if sshpass -p "$LAB_PASS" ssh-copy-id \
            -i /home/vscode/.ssh/lab_key.pub \
            -o StrictHostKeyChecking=no \
            -o ConnectTimeout=10 \
            "${LAB_USER}@${IP}" 2>/dev/null; then
            echo -e "${G}done${N}"
        else
            echo -e "${Y}node not ready yet${N}"
        fi
    fi
done

echo ""
echo -e "  Run: ${Y}ansible all -m ping${N} to verify"
echo ""
