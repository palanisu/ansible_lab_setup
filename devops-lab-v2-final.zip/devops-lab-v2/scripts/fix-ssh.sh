#!/usr/bin/env bash
# =================================================================
# fix-ssh.sh — Manual SSH key fix for all managed nodes
# Run this if post-create.sh SSH step failed.
# Usage: bash scripts/fix-ssh.sh
#        bash scripts/fix-ssh.sh Training@123  (custom password)
# =================================================================
G="\033[0;32m"; C="\033[0;36m"; Y="\033[1;33m"; R="\033[0;31m"; N="\033[0m"

LAB_USER="ansible"
LAB_PASS="${1:-${ANSIBLE_NODE_PASSWORD:-Training@123}}"

declare -A NODES=(
    ["web01"]="192.168.55.21"
    ["web02"]="192.168.55.22"
    ["db01"]="192.168.55.23"
)

echo -e "\n${C}▶  SSH Key Fix — distributing key to all managed nodes${N}"
echo -e "   User: ${LAB_USER} | Password: ${LAB_PASS}\n"

# Check sshpass is available
if ! command -v sshpass &>/dev/null; then
    echo -e "${Y}Installing sshpass...${N}"
    sudo apt-get install -y sshpass -qq
fi

ALL_OK=true
for NAME in "${!NODES[@]}"; do
    IP="${NODES[$NAME]}"
    echo -n "  ssh-copy-id → ${LAB_USER}@$NAME ($IP) ... "

    for ATTEMPT in 1 2 3; do
        if sshpass -p "$LAB_PASS" ssh-copy-id \
            -i /home/vscode/.ssh/lab_key.pub \
            -o StrictHostKeyChecking=no \
            -o ConnectTimeout=10 \
            "${LAB_USER}@${IP}" 2>/dev/null; then
            echo -e "${G}✓ done${N}"
            break
        fi
        if [ $ATTEMPT -lt 3 ]; then
            echo -n " retry $ATTEMPT... "
            sleep 3
        else
            echo -e "${R}✗ FAILED${N}"
            ALL_OK=false
        fi
    done
done

echo ""
if $ALL_OK; then
    echo -e "${G}✓ SSH keys distributed. Testing with Ansible...${N}\n"
    ansible all -m ping
else
    echo -e "${Y}⚠  Some nodes failed. Check:${N}"
    echo "  1. Node is running:   docker ps"
    echo "  2. Password correct:  sshpass -p '${LAB_PASS}' ssh ${LAB_USER}@192.168.55.21"
    echo "  3. Port open:         nc -z 192.168.55.21 22"
fi
