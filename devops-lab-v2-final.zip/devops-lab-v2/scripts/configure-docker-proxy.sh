#!/usr/bin/env bash
# =================================================================
# configure-docker-proxy.sh
#
# If your org uses an HTTP proxy (Squid, Zscaler, etc.)
# this script configures Docker to route pulls through it.
#
# Ask your IT/network team for:
#   - Proxy hostname and port (e.g. proxy.company.com:8080)
#   - Whether proxy requires auth
#   - No-proxy list (internal domains to skip)
#
# Usage:
#   export HTTP_PROXY_URL=http://proxy.company.com:8080
#   bash scripts/configure-docker-proxy.sh
# =================================================================
set -e
G="\033[0;32m"; C="\033[0;36m"; Y="\033[1;33m"; N="\033[0m"

PROXY_URL="${HTTP_PROXY_URL:-}"
if [ -z "$PROXY_URL" ]; then
    echo -e "${Y}Set your proxy URL first:${N}"
    echo "  export HTTP_PROXY_URL=http://proxy.company.com:8080"
    echo "  bash scripts/configure-docker-proxy.sh"
    exit 1
fi

echo -e "${C}Configuring Docker proxy: $PROXY_URL${N}"

# ── Docker daemon proxy (for docker pull) ─────────────────────────────────────
sudo mkdir -p /etc/systemd/system/docker.service.d
sudo tee /etc/systemd/system/docker.service.d/proxy.conf << EOF
[Service]
Environment="HTTP_PROXY=${PROXY_URL}"
Environment="HTTPS_PROXY=${PROXY_URL}"
Environment="NO_PROXY=localhost,127.0.0.1,172.20.0.0/24,mcr.microsoft.com,*.azurecr.io,*.microsoft.com"
EOF

# ── Docker Desktop proxy (write config file) ──────────────────────────────────
mkdir -p ~/.docker
cat > ~/.docker/config.json << EOF
{
  "proxies": {
    "default": {
      "httpProxy":  "${PROXY_URL}",
      "httpsProxy": "${PROXY_URL}",
      "noProxy":    "localhost,127.0.0.1,172.20.0.0/24,mcr.microsoft.com,*.azurecr.io,*.microsoft.com"
    }
  }
}
EOF

# ── WSL / shell proxy ─────────────────────────────────────────────────────────
if ! grep -q "HTTP_PROXY" ~/.bashrc; then
    cat >> ~/.bashrc << EOF

# Corporate proxy
export http_proxy="${PROXY_URL}"
export https_proxy="${PROXY_URL}"
export HTTP_PROXY="${PROXY_URL}"
export HTTPS_PROXY="${PROXY_URL}"
export no_proxy="localhost,127.0.0.1,*.microsoft.com,*.azurecr.io"
EOF
fi

# ── pip proxy ─────────────────────────────────────────────────────────────────
mkdir -p ~/.config/pip
cat > ~/.config/pip/pip.conf << EOF
[global]
proxy = ${PROXY_URL}
trusted-host = pypi.org files.pythonhosted.org
EOF

echo ""
echo -e "${G}✓ Proxy configured for Docker, WSL shell, and pip${N}"
echo ""
echo -e "${Y}Now restart Docker Desktop and run:${N}"
echo "  source ~/.bashrc"
echo "  docker pull mcr.microsoft.com/devcontainers/base:ubuntu-22.04"
echo ""
echo -e "${C}If still blocked, check with IT:${N}"
echo "  curl -v --proxy $PROXY_URL https://mcr.microsoft.com"
