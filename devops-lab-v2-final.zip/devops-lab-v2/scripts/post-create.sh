#!/usr/bin/env bash
# =================================================================
# post-create.sh — Runs ONCE when Dev Container is first created
#
# SSH key distribution strategy:
#   1. Generate SSH key pair
#   2. Write pubkey to shared volume  (Method A — no password)
#   3. Use sshpass + ssh-copy-id      (Method B — password fallback)
#   Both methods run so SSH works regardless of volume timing.
#
# Managed node password: Training@123  (set in Dockerfile.managed)
# =================================================================
set -e
G="\033[0;32m"; C="\033[0;36m"; Y="\033[1;33m"; R="\033[0;31m"; N="\033[0m"
ok()    { echo -e "${G}✓  $*${N}"; }
step()  { echo -e "\n${C}▶  $*${N}"; }
warn()  { echo -e "${Y}⚠  $*${N}"; }
info()  { echo -e "   $*"; }

# ── Managed node credentials ──────────────────────────────────────
# Must match ANSIBLE_PASSWORD ARG in Dockerfile.managed
LAB_USER="ansible"
LAB_PASS="${ANSIBLE_NODE_PASSWORD:-Training@123}"

# ── Managed node IPs (must match docker-compose.yml) ─────────────
declare -A NODES=(
    ["web01"]="192.168.55.21"
    ["web02"]="192.168.55.22"
    ["db01"]="192.168.55.23"
)

echo ""
echo -e "${C}╔══════════════════════════════════════════════════════╗${N}"
echo -e "${C}║    DevOps Training Lab v2 — First-Time Setup        ║${N}"
echo -e "${C}╚══════════════════════════════════════════════════════╝${N}"
echo ""

# ════════════════════════════════════════════════════════════════
# STEP 1 — Generate SSH key pair
# ════════════════════════════════════════════════════════════════
step "Generating SSH key pair..."
mkdir -p /home/vscode/.ssh && chmod 700 /home/vscode/.ssh

if [ ! -f /home/vscode/.ssh/lab_key ]; then
    ssh-keygen -t ed25519 \
        -C "devops-lab-$(date +%Y%m%d)" \
        -f /home/vscode/.ssh/lab_key \
        -N "" -q
    chmod 600 /home/vscode/.ssh/lab_key
    chmod 644 /home/vscode/.ssh/lab_key.pub
    ok "SSH key generated: ~/.ssh/lab_key"
else
    ok "SSH key already exists — reusing ~/.ssh/lab_key"
fi

PUB_KEY=$(cat /home/vscode/.ssh/lab_key.pub)

# ════════════════════════════════════════════════════════════════
# STEP 2 — Method A: Shared volume
# ════════════════════════════════════════════════════════════════
step "Method A: Writing pubkey to shared volume..."
mkdir -p /ssh-keys
cp /home/vscode/.ssh/lab_key.pub /ssh-keys/lab_key.pub
chmod 644 /ssh-keys/lab_key.pub
ok "Pubkey written to /ssh-keys/lab_key.pub"

# ════════════════════════════════════════════════════════════════
# STEP 3 — Write SSH client config
# ════════════════════════════════════════════════════════════════
step "Writing SSH client config..."
cat > /home/vscode/.ssh/config << SSHCFG
# DevOps Lab — managed nodes
Host web01
    HostName 192.168.55.21
    User ansible
    IdentityFile ~/.ssh/lab_key
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
    LogLevel ERROR
    ConnectTimeout 10

Host web02
    HostName 192.168.55.22
    User ansible
    IdentityFile ~/.ssh/lab_key
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
    LogLevel ERROR
    ConnectTimeout 10

Host db01
    HostName 192.168.55.23
    User ansible
    IdentityFile ~/.ssh/lab_key
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
    LogLevel ERROR
    ConnectTimeout 10
SSHCFG
chmod 600 /home/vscode/.ssh/config
ok "SSH client config written"

# ════════════════════════════════════════════════════════════════
# STEP 4 — Wait for managed nodes to be reachable
# ════════════════════════════════════════════════════════════════
step "Waiting for managed nodes to start SSH..."
echo ""

for NAME in "${!NODES[@]}"; do
    IP="${NODES[$NAME]}"
    echo -n "  Waiting for $NAME ($IP) SSH port... "
    WAITED=0
    until nc -z -w2 "$IP" 22 2>/dev/null || [ $WAITED -ge 60 ]; do
        sleep 2
        WAITED=$((WAITED+2))
        echo -n "."
    done
    if nc -z -w2 "$IP" 22 2>/dev/null; then
        echo -e "  ${G}up${N}"
    else
        echo -e "  ${Y}timeout — will retry below${N}"
    fi
done

# ════════════════════════════════════════════════════════════════
# STEP 5 — Method B: ssh-copy-id with password
# This is the RELIABLE method — works even if shared volume
# wasn't ready when entrypoint.sh ran.
# ════════════════════════════════════════════════════════════════
step "Method B: Distributing SSH key via ssh-copy-id (password auth)..."
echo ""
info "Using user: ${LAB_USER} | password: ${LAB_PASS}"
echo ""

ALL_OK=true
for NAME in "${!NODES[@]}"; do
    IP="${NODES[$NAME]}"
    echo -n "  ssh-copy-id → $NAME ($IP) ... "

    # Try up to 3 times (node may still be starting)
    SUCCESS=false
    for ATTEMPT in 1 2 3; do
        if sshpass -p "$LAB_PASS" ssh-copy-id \
            -i /home/vscode/.ssh/lab_key.pub \
            -o StrictHostKeyChecking=no \
            -o ConnectTimeout=10 \
            "${LAB_USER}@${IP}" 2>/dev/null; then
            SUCCESS=true
            break
        fi
        [ $ATTEMPT -lt 3 ] && sleep 3
    done

    if $SUCCESS; then
        echo -e "${G}done${N}"
    else
        echo -e "${R}FAILED — check node is running and password is correct${N}"
        ALL_OK=false
    fi
done

echo ""
if $ALL_OK; then
    ok "SSH keys distributed to all managed nodes"
else
    warn "Some nodes failed — run: bash scripts/fix-ssh.sh"
fi

# ════════════════════════════════════════════════════════════════
# STEP 6 — Verify key-based SSH works (no password)
# ════════════════════════════════════════════════════════════════
step "Verifying key-based SSH (no password)..."
echo ""
ALL_SSH_OK=true
for NAME in "${!NODES[@]}"; do
    IP="${NODES[$NAME]}"
    echo -n "  SSH key test → $NAME ($IP) ... "
    if ssh -o StrictHostKeyChecking=no \
           -o ConnectTimeout=5 \
           -o BatchMode=yes \
           -i /home/vscode/.ssh/lab_key \
           "${LAB_USER}@${IP}" "echo ok" 2>/dev/null | grep -q ok; then
        echo -e "${G}✓ key auth works${N}"
    else
        echo -e "${Y}⚠ key auth not ready yet${N}"
        ALL_SSH_OK=false
    fi
done

# ════════════════════════════════════════════════════════════════
# STEP 7 — Configure Git
# ════════════════════════════════════════════════════════════════
step "Configuring Git..."
git config --global init.defaultBranch main
git config --global pull.rebase false
git config --global core.autocrlf input
git config --global core.editor "code --wait"
git config --global alias.lg   "log --oneline --graph --all --decorate"
git config --global alias.st   "status -sb"
git config --global alias.undo "reset --soft HEAD~1"

if [ -z "$(git config --global user.name 2>/dev/null)" ]; then
    warn "Git identity not set. Run:"
    info "git config --global user.name  \"Your Name\""
    info "git config --global user.email \"you@company.com\""
else
    ok "Git: $(git config --global user.name) <$(git config --global user.email)>"
fi

# ════════════════════════════════════════════════════════════════
# STEP 8 — Install Ansible collections
# ════════════════════════════════════════════════════════════════
step "Installing Ansible Galaxy collections..."
if [ -f /workspace/ansible/requirements.yml ]; then
    ansible-galaxy collection install \
        -r /workspace/ansible/requirements.yml \
        --ignore-errors -q
fi
ok "Collections installed"

# ════════════════════════════════════════════════════════════════
# STEP 9 — Ansible ping test
# ════════════════════════════════════════════════════════════════
step "Running Ansible connectivity test..."
cd /workspace
echo ""
if ansible all -m ping --timeout=10 2>/dev/null; then
    echo ""
    ok "Ansible can reach all managed nodes!"
else
    echo ""
    warn "Ansible ping failed — run: ansible all -m ping"
fi

# ════════════════════════════════════════════════════════════════
# DONE
# ════════════════════════════════════════════════════════════════
echo ""
echo -e "${G}╔══════════════════════════════════════════════════════╗${N}"
echo -e "${G}║            Lab Environment Ready!  🎉               ║${N}"
echo -e "${G}╚══════════════════════════════════════════════════════╝${N}"
echo ""
echo -e "  ${C}Quick commands:${N}"
echo -e "  ${Y}ansible all -m ping${N}"
echo -e "  ${Y}ansible-inventory --graph${N}"
echo -e "  ${Y}bash git-labs/lab1-setup.sh${N}"
echo -e "  ${Y}ansible-playbook ansible/playbooks/03-install-nginx.yml${N}"
echo ""
echo -e "  ${C}Managed node creds (for direct SSH if needed):${N}"
echo -e "  ${Y}ssh ansible@web01${N}   (key-based, no password)"
echo -e "  User: ansible | Initial password: ${LAB_PASS}"
echo ""
