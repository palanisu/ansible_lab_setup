#!/usr/bin/env bash
# =================================================================
# build-and-push-to-acr.sh
#
# TRAINER RUNS THIS ONCE from any machine that can reach Docker Hub
# (e.g. home laptop, cloud VM, Azure Cloud Shell).
#
# After this, all attendees pull from your org ACR — no Docker Hub.
#
# Usage:
#   export ACR_NAME=mycompanyacr
#   bash scripts/build-and-push-to-acr.sh
# =================================================================
set -e
G="\033[0;32m"; C="\033[0;36m"; Y="\033[1;33m"; N="\033[0m"
ok()   { echo -e "${G}✓  $*${N}"; }
step() { echo -e "\n${C}▶  $*${N}"; }

# ── Config ────────────────────────────────────────────────────────────────────
ACR_NAME="${ACR_NAME:-}"
if [ -z "$ACR_NAME" ]; then
    echo -e "${Y}Set your ACR name first:${N}"
    echo "  export ACR_NAME=mycompanyacr"
    echo "  bash scripts/build-and-push-to-acr.sh"
    exit 1
fi

ACR_LOGIN_SERVER="${ACR_NAME}.azurecr.io"
CONTROL_TAG="${ACR_LOGIN_SERVER}/devops-lab-control:v2"
MANAGED_TAG="${ACR_LOGIN_SERVER}/devops-lab-managed:v2"

echo -e "${C}"
echo "╔══════════════════════════════════════════════════════╗"
echo "║  DevOps Lab — Build & Push Images to ACR             ║"
echo "║  ACR: ${ACR_LOGIN_SERVER}"
echo "╚══════════════════════════════════════════════════════╝"
echo -e "${N}"

# ── Step 1: Login to ACR ──────────────────────────────────────────────────────
step "Logging in to Azure Container Registry..."
az acr login --name "$ACR_NAME"
ok "Logged in to $ACR_LOGIN_SERVER"

# ── Step 2: Build control node image ─────────────────────────────────────────
step "Building control node image (Ansible + Git + AzCLI)..."
docker build \
    --platform linux/amd64 \
    --tag "$CONTROL_TAG" \
    --file .devcontainer/Dockerfile \
    .devcontainer/
ok "Control node image built"

# ── Step 3: Build managed node image ─────────────────────────────────────────
step "Building managed node image (SSH + Python3)..."
docker build \
    --platform linux/amd64 \
    --tag "$MANAGED_TAG" \
    --file managed-nodes/Dockerfile.managed \
    managed-nodes/
ok "Managed node image built"

# ── Step 4: Push to ACR ──────────────────────────────────────────────────────
step "Pushing control node image to ACR..."
docker push "$CONTROL_TAG"
ok "Pushed: $CONTROL_TAG"

step "Pushing managed node image to ACR..."
docker push "$MANAGED_TAG"
ok "Pushed: $MANAGED_TAG"

# ── Step 5: Show pull instructions ───────────────────────────────────────────
echo ""
echo -e "${G}╔══════════════════════════════════════════════════════╗${N}"
echo -e "${G}║  Images pushed to ACR successfully!                  ║${N}"
echo -e "${G}╚══════════════════════════════════════════════════════╝${N}"
echo ""
echo -e "${C}Share these instructions with your team:${N}"
echo ""
echo "  1. Login to ACR (once per machine):"
echo -e "     ${Y}az login${N}"
echo -e "     ${Y}az acr login --name ${ACR_NAME}${N}"
echo ""
echo "  2. Clone the repo and set ACR name:"
echo -e "     ${Y}git clone <repo-url>${N}"
echo -e "     ${Y}cd devops-lab${N}"
echo -e "     ${Y}export ACR_NAME=${ACR_NAME}${N}"
echo ""
echo "  3. Open in VS Code (uses docker-compose.acr.yml):"
echo -e "     ${Y}code .${N}"
echo ""
echo -e "  ${C}Image details:${N}"
echo "  Control node: $CONTROL_TAG"
echo "  Managed node: $MANAGED_TAG"
echo ""
