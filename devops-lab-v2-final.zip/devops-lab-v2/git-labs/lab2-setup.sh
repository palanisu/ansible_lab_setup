#!/usr/bin/env bash
G="\033[0;32m"; C="\033[0;36m"; Y="\033[1;33m"; N="\033[0m"
LAB=~/git-labs/lab2
echo -e "\n${C}Git Lab 2 — Branching, Merging and Conflict Resolution${N}\n"
rm -rf $LAB && mkdir -p $LAB && cd $LAB && git init -q
printf 'from flask import Flask\napp = Flask(__name__)\n\n@app.route("/")\ndef home():\n    return "Welcome"\n' > app.py
echo "Flask==3.0.0" > requirements.txt
git add . && git commit -q -m "Initial: Flask app skeleton"
echo -e "${G}✓ Repo ready: $LAB${N}\n"
echo -e "${C}Tasks:${N}"
echo "  git switch -c feature/login"
echo "  # Add @app.route('/login') to app.py"
echo "  git add app.py && git commit -m 'Add login route'"
echo "  git switch main && git switch -c feature/dashboard"
echo "  # Add @app.route('/dashboard') AND change home() return value"
echo "  git add app.py && git commit -m 'Add dashboard route'"
echo "  git switch main && git merge feature/login          # clean"
echo "  git merge feature/dashboard                         # CONFLICT"
echo "  code app.py                                         # resolve"
echo "  git add app.py && git commit -m 'Merge: resolve conflict'"
echo "  git log --oneline --graph --all"
echo -e "\nOpen: ${Y}code $LAB${N}"
