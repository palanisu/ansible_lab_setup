#!/usr/bin/env bash
G="\033[0;32m"; C="\033[0;36m"; Y="\033[1;33m"; N="\033[0m"
LAB=~/git-labs/lab3
echo -e "\n${C}Git Lab 3 — Interactive Rebase and Clean History${N}\n"
rm -rf $LAB && mkdir -p $LAB && cd $LAB && git init -q
echo "# Auth App" > README.md
git add . && git commit -q -m "Initial commit"
git switch -q -c feature/user-auth
echo "def register(): pass" >> auth.py && git add . && git commit -q -m "WIP register"
echo "def login(): pass"    >> auth.py && git add . && git commit -q -m "add loginn"
echo "def logout(): pass"   >> auth.py && git add . && git commit -q -m "typo fix"
echo "def reset(): pass"    >> auth.py && git add . && git commit -q -m "forgot reset"
echo "# Auth module"        >> auth.py && git add . && git commit -q -m "add comment"
echo "VERSION = '1.0'"     > version.py && git add . && git commit -q -m "version"
echo "DEBUG = False"       >> version.py && git add . && git commit -q -m "debug off"
echo -e "${G}✓ 7 messy commits created${N}"
git log --oneline
echo ""
echo -e "${C}Tasks:${N}"
echo "  git rebase -i HEAD~7"
echo "  → squash commits 1-5 into: 'Add user authentication module'"
echo "  → squash commits 6-7 into: 'Add version config'"
echo "  git log --oneline    # should show 3 commits total"
echo "  Try 'reword' to rename a commit message"
echo "  Try 'drop' to delete a commit, then recover with git reflog"
echo -e "\nOpen: ${Y}code $LAB${N}"
