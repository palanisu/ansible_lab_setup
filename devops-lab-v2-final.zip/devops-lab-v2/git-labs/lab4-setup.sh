#!/usr/bin/env bash
G="\033[0;32m"; C="\033[0;36m"; Y="\033[1;33m"; N="\033[0m"
LAB=~/git-labs/lab4
echo -e "\n${C}Git Lab 4 — Full GitFlow Workflow${N}\n"
rm -rf $LAB && mkdir -p $LAB && cd $LAB && git init -q
echo "1.0.0" > VERSION
echo "print('App v1.0.0')" > app.py
echo "# Changelog\n## v1.0.0 - Initial" > CHANGELOG.md
git add . && git commit -q -m "Initial release"
git tag -a v1.0.0 -m "Release 1.0.0"
git switch -q -c develop
echo -e "${G}✓ Ready — main tagged v1.0.0, develop created${N}"
git log --oneline --graph --all
echo ""
echo -e "${C}GitFlow tasks:${N}"
echo ""
echo -e "${Y}FEATURE:${N}"
echo "  git switch develop && git switch -c feature/user-profile"
echo "  echo 'def get_profile(uid): return {}' >> app.py"
echo "  git add . && git commit -m 'Add user profile'"
echo "  git switch develop && git merge --no-ff feature/user-profile -m 'Merge feature'"
echo "  git branch -d feature/user-profile"
echo ""
echo -e "${Y}RELEASE:${N}"
echo "  git switch -c release/1.1.0"
echo "  echo '1.1.0' > VERSION && git commit -am 'Bump to 1.1.0'"
echo "  git switch main && git merge --no-ff release/1.1.0 -m 'Release v1.1.0'"
echo "  git tag -a v1.1.0 -m 'Release 1.1.0'"
echo "  git switch develop && git merge --no-ff release/1.1.0 -m 'Merge release'"
echo "  git branch -d release/1.1.0"
echo ""
echo -e "${Y}HOTFIX:${N}"
echo "  git switch main && git switch -c hotfix/fix-crash"
echo "  echo 'def safe(): pass' >> app.py && git commit -am 'Fix crash'"
echo "  echo '1.1.1' > VERSION && git commit -am 'Bump to 1.1.1'"
echo "  git switch main && git merge --no-ff hotfix/fix-crash -m 'Hotfix v1.1.1'"
echo "  git tag -a v1.1.1 -m 'Hotfix 1.1.1'"
echo "  git switch develop && git merge --no-ff hotfix/fix-crash -m 'Merge hotfix'"
echo "  git branch -d hotfix/fix-crash"
echo "  git log --oneline --graph --all && git tag -l"
echo -e "\nOpen: ${Y}code $LAB${N}"
