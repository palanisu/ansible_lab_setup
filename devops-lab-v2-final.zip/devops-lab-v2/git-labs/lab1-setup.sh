#!/usr/bin/env bash
G="\033[0;32m"; C="\033[0;36m"; Y="\033[1;33m"; N="\033[0m"
LAB=~/git-labs/lab1
echo -e "\n${C}Git Lab 1 — Commits, Selective Staging and Undo${N}\n"
rm -rf $LAB && mkdir -p $LAB/src $LAB/tests && cd $LAB
git init -q && echo -e "${G}✓ Repo ready: $LAB${N}\n"
echo "# DevOps Training Project" > README.md
echo "Flask==3.0.0" > requirements.txt
printf 'from flask import Flask\napp = Flask(__name__)\n\n@app.route("/")\ndef home():\n    return "DevOps Training App"\n' > src/app.py
echo "def test_placeholder(): assert True" > tests/test_app.py
echo -e "${C}Tasks to complete:${N}"
echo "  1. git status"
echo "  2. git add README.md && git commit -m 'Add README'"
echo "  3. git add requirements.txt && git commit -m 'Add requirements'"
echo "  4. git add src/ tests/ && git commit -m 'Add app skeleton'"
echo "  5. Add two functions to src/app.py (greet + farewell)"
echo "  6. git add -p src/app.py    # press y for greet, n for farewell"
echo "  7. git commit -m 'Add greet function'"
echo "  8. git add src/app.py && git commit -m 'Add farewell function'"
echo "  9. git log --oneline --graph"
echo " 10. Make bad commit → git reset --soft HEAD~1"
echo " 11. Make another bad commit → git reset --hard HEAD~1"
echo " 12. Make one more bad commit → git revert HEAD --no-edit"
echo ""
echo -e "${Y}Tip: git add -p keys: y=stage, n=skip, s=split, ?=help${N}"
echo -e "Open: ${Y}code $LAB${N}"
