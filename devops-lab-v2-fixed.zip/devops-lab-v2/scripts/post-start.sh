#!/usr/bin/env bash
# =================================================================
# post-start.sh — Runs every time the Dev Container starts
# Re-publishes the SSH key to shared volume if needed.
# No docker exec. No Docker CLI needed.
# =================================================================
G="\033[0;32m"; C="\033[0;36m"; Y="\033[1;33m"; N="\033[0m"

echo -e "${C}▶  Checking managed node SSH access...${N}"

# Ensure pubkey is in the shared volume
if [ -f /home/vscode/.ssh/lab_key.pub ]; then
    mkdir -p /ssh-keys
    cp /home/vscode/.ssh/lab_key.pub /ssh-keys/lab_key.pub
    chmod 644 /ssh-keys/lab_key.pub
fi

# Check each managed node
NODES=("172.20.0.21:web01" "172.20.0.22:web02" "172.20.0.23:db01")
ALL_OK=true

for NODE in "${NODES[@]}"; do
    IP="${NODE%%:*}"; NAME="${NODE##*:}"
    if ssh -o StrictHostKeyChecking=no \
           -o ConnectTimeout=5 \
           -o BatchMode=yes \
           -i /home/vscode/.ssh/lab_key \
           ansible@${IP} true 2>/dev/null; then
        echo -e "  ${G}✓ $NAME ($IP) reachable${N}"
    else
        echo -e "  ${Y}⚠ $NAME ($IP) not ready — node may still be starting${N}"
        ALL_OK=false
    fi
done

if $ALL_OK; then
    echo -e "\n${G}✓ All nodes ready. Run: ansible all -m ping${N}\n"
else
    echo -e "\n${Y}⚠ Some nodes not ready. Wait 10s and run:${N}"
    echo -e "  ${Y}bash scripts/post-start.sh${N}\n"
fi
