#!/usr/bin/env bash
# =================================================================
# post-create.sh — Runs ONCE when Dev Container is first created
#
# Fix B implementation:
#   1. Generate SSH key pair
#   2. Write public key to /ssh-keys/lab_key.pub  (shared volume)
#   3. Managed nodes read it automatically via entrypoint.sh
#   No docker exec needed. Works on any Linux/Ubuntu Docker host.
# =================================================================
set -e
G="\033[0;32m"; C="\033[0;36m"; Y="\033[1;33m"; R="\033[0;31m"; N="\033[0m"
ok()   { echo -e "${G}✓  $*${N}"; }
step() { echo -e "\n${C}▶  $*${N}"; }
warn() { echo -e "${Y}⚠  $*${N}"; }

echo ""
echo -e "${C}╔══════════════════════════════════════════════════════╗${N}"
echo -e "${C}║    DevOps Training Lab v2 — First-Time Setup        ║${N}"
echo -e "${C}╚══════════════════════════════════════════════════════╝${N}"

# ── Step 1: Generate SSH key pair ─────────────────────────────────
step "Generating SSH key pair..."
mkdir -p /home/vscode/.ssh
chmod 700 /home/vscode/.ssh

if [ ! -f /home/vscode/.ssh/lab_key ]; then
    ssh-keygen -t ed25519 \
        -C "devops-lab-$(hostname)-$(date +%Y%m%d)" \
        -f /home/vscode/.ssh/lab_key \
        -N "" -q
    chmod 600 /home/vscode/.ssh/lab_key
    chmod 644 /home/vscode/.ssh/lab_key.pub
    ok "SSH key generated: ~/.ssh/lab_key"
else
    ok "SSH key already exists — reusing"
fi

# ── Step 2: FIX B — Write pubkey to shared volume ────────────────
# Managed nodes read /ssh-keys/lab_key.pub from this shared volume
# via their entrypoint.sh. No docker exec needed.
step "Publishing SSH public key to shared volume..."
mkdir -p /ssh-keys
cp /home/vscode/.ssh/lab_key.pub /ssh-keys/lab_key.pub
chmod 644 /ssh-keys/lab_key.pub
ok "Public key written to /ssh-keys/lab_key.pub (shared volume)"
ok "Managed nodes will pick this up automatically via their entrypoint"

# ── Step 3: SSH client config ─────────────────────────────────────
step "Writing SSH client config..."
cat > /home/vscode/.ssh/config << 'SSHCFG'
Host web01
    HostName 172.20.0.21
    User ansible
    IdentityFile ~/.ssh/lab_key
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
    LogLevel ERROR
    ConnectTimeout 10

Host web02
    HostName 172.20.0.22
    User ansible
    IdentityFile ~/.ssh/lab_key
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
    LogLevel ERROR
    ConnectTimeout 10

Host db01
    HostName 172.20.0.23
    User ansible
    IdentityFile ~/.ssh/lab_key
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
    LogLevel ERROR
    ConnectTimeout 10
SSHCFG
chmod 600 /home/vscode/.ssh/config
ok "SSH client config written"

# ── Step 4: Wait for managed nodes to apply the key ──────────────
step "Waiting for managed nodes to configure SSH..."
NODES=("172.20.0.21:web01" "172.20.0.22:web02" "172.20.0.23:db01")
ALL_READY=false

for ATTEMPT in $(seq 1 30); do
    ALL_READY=true
    for NODE in "${NODES[@]}"; do
        IP="${NODE%%:*}"; NAME="${NODE##*:}"
        if ! ssh -o StrictHostKeyChecking=no \
                 -o ConnectTimeout=3 \
                 -o BatchMode=yes \
                 -i /home/vscode/.ssh/lab_key \
                 ansible@${IP} true 2>/dev/null; then
            ALL_READY=false
        fi
    done
    if $ALL_READY; then
        break
    fi
    echo -e "  ${Y}Attempt $ATTEMPT/30 — nodes still starting, waiting 3s...${N}"
    sleep 3
done

if $ALL_READY; then
    ok "All managed nodes are SSH-ready!"
else
    warn "Some nodes not ready yet — run: bash scripts/post-start.sh"
fi

# ── Step 5: Configure Git ─────────────────────────────────────────
step "Configuring Git..."
git config --global init.defaultBranch main
git config --global pull.rebase false
git config --global core.autocrlf input
git config --global core.editor "code --wait"
git config --global alias.lg   "log --oneline --graph --all --decorate"
git config --global alias.st   "status -sb"
git config --global alias.undo "reset --soft HEAD~1"

if [ -z "$(git config --global user.name 2>/dev/null)" ]; then
    warn "Git identity not set. Please run:"
    echo -e "  ${Y}git config --global user.name  \"Your Name\"${N}"
    echo -e "  ${Y}git config --global user.email \"you@company.com\"${N}"
else
    ok "Git: $(git config --global user.name) <$(git config --global user.email)>"
fi

# ── Step 6: Install Ansible collections ──────────────────────────
step "Installing Ansible Galaxy collections..."
if [ -f /workspace/ansible/requirements.yml ]; then
    ansible-galaxy collection install \
        -r /workspace/ansible/requirements.yml \
        --ignore-errors -q
fi
ok "Collections ready"

# ── Step 7: Ansible ping test ─────────────────────────────────────
step "Running Ansible connectivity test..."
cd /workspace
if ansible all -m ping --timeout=10 2>/dev/null; then
    ok "Ansible can reach all managed nodes!"
else
    warn "Connectivity test failed — run: ansible all -m ping"
fi

# ── Done ──────────────────────────────────────────────────────────
echo ""
echo -e "${G}╔══════════════════════════════════════════════════════╗${N}"
echo -e "${G}║            Lab Environment Ready!  🎉               ║${N}"
echo -e "${G}╚══════════════════════════════════════════════════════╝${N}"
echo ""
echo -e "  ${C}Quick commands:${N}"
echo -e "  ${Y}ansible all -m ping${N}                           Test nodes"
echo -e "  ${Y}ansible-inventory --graph${N}                     View inventory tree"
echo -e "  ${Y}bash git-labs/lab1-setup.sh${N}                   Git Lab 1"
echo -e "  ${Y}ansible-playbook ansible/playbooks/03-install-nginx.yml${N}"
echo ""
echo -e "  ${C}VS Code Tasks:${N} Ctrl+Shift+P → Tasks: Run Task"
echo ""
