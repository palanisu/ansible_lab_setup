#!/bin/bash
# =================================================================
# entrypoint.sh — Managed Node startup script
#
# Waits for /ssh-keys/lab_key.pub to appear in the shared volume,
# then adds it to ansible user's authorized_keys.
# This removes ALL need for docker exec from the control node.
# =================================================================

AUTH_KEYS="/home/ansible/.ssh/authorized_keys"
PUB_KEY_FILE="/ssh-keys/lab_key.pub"

echo "[managed-node] Starting SSH key setup..."

# Wait up to 60 seconds for the shared key file to appear
WAITED=0
until [ -f "$PUB_KEY_FILE" ] || [ $WAITED -ge 60 ]; do
    echo "[managed-node] Waiting for $PUB_KEY_FILE ... (${WAITED}s)"
    sleep 2
    WAITED=$((WAITED + 2))
done

if [ -f "$PUB_KEY_FILE" ]; then
    PUB_KEY=$(cat "$PUB_KEY_FILE")
    # Add key if not already present
    if ! grep -qF "$PUB_KEY" "$AUTH_KEYS" 2>/dev/null; then
        echo "$PUB_KEY" >> "$AUTH_KEYS"
        chmod 600 "$AUTH_KEYS"
        chown ansible:ansible "$AUTH_KEYS"
        echo "[managed-node] SSH public key installed"
    else
        echo "[managed-node] SSH public key already present"
    fi
else
    echo "[managed-node] WARNING: Key file not found after 60s — SSH will fail"
fi

# Start SSH daemon in foreground
echo "[managed-node] Starting sshd..."
exec /usr/sbin/sshd -D
